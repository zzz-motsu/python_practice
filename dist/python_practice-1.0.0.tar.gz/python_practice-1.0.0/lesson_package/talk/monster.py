from lesson_package.tools import utils

def sing():
    return '##fhftjfykf'

def cry():
    return utils.say_twice('dhdhdhtdjdtkj')