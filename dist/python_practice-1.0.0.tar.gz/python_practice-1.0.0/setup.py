from setuptools import setup

setup(
    name='python_practice',
    version='1.0.0',
    packages=['lesson_package', 'lesson_package.talk', 'lesson_package.tools'],
    url='https://twawpeakreplica.com',
    license='Free',
    author='tokamoto',
    author_email='',
    description='Sample package'
)
